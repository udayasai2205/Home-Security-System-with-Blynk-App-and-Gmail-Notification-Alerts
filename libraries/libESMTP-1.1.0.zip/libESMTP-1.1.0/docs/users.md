# Users

Please leave a comment on issue #2 if your project uses libESMTP, preferably
with a link to the project web site. A list of users will be added here at some
point in the future.  It's always good to know that this work is useful to the
community; without knowing who uses libESMTP, it is impossible to judge whether
and how much effort should be invested in its future.


