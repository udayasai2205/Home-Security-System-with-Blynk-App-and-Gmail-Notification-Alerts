Legacy Files
------------

Since libESMTP is now hosted on GitHub and managed using git, the previous
ChangeLog and NEWS files are obsolete. Neither has been maintained for some
time They are preserved here for those interested.

Other obsolete files are either deleted or will be moved to the libESMTP Wiki.

.. toctree::
   :maxdepth: 2

   NEWS
   ChangeLog
