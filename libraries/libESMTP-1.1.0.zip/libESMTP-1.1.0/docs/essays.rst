Essays
======

A small collection of pieces I've written on libESMTP.

Essentially where I've been with this project and, after two decades, where
I might go with it.

.. toctree::
   :maxdepth: 1

   rationale
   retrospective
   critique
