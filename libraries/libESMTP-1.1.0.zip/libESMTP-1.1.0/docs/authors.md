# Author

libESMTP's primary author is Brian Stafford \<brian·stafford60﹫gmail·com>.

Support for verifying X.509 certificates was contributed by Pawel Salek.

## Contributors

Over time, particularly in libESMTP's early development, many have reported and
contributed bug-fixes for which I am grateful.  Some are listed below;
apologies to any who have been missed.

* Bas ten Berge \<sam·ten·berge﹫hccnet·nl>
* Chris Richards \<Chris·Richards﹫red-m·com>
* Colin Phipps
* Dmitry Maksyoma \<dmaks﹫esphion·com>
* Heikki Lindholm \<heikki·lindholm﹫ipnetworks·fi>
* Matthias Andree \<matthias·andree﹫gmx·de>
* Pawel Salek \<pawsa﹫theochem·kth·se>
* Ronald F. Guilmette
* Thomas Deselaers \<deselaers﹫gmail·com>
