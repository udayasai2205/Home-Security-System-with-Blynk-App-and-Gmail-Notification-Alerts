# Installation

Installation instructions may be found in `docs/download.md`.
